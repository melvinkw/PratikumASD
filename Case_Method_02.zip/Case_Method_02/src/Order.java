public class Order {
    int OrderCode;
    String OrderName;
    int price;

    public Order(int OrderCode, String OrderName, int price){
        this.OrderCode = OrderCode;
        this.OrderName = OrderName;
        this.price = price;
    }
}
