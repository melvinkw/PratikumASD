public class DoubleLinkedListBuyer {
    NodeBuyer head; 
    NodeBuyer tail; 
    int size;

    public DoubleLinkedListBuyer() {
        head = null;
        tail = null;
        size = 0;
    }

    public boolean isEmpty() {
        return head == null; 
    }

    public void addLast(Buyer item) {
        if (isEmpty()) {
            head = new NodeBuyer(null, item, null);
            tail = head; 
        } else {
            NodeBuyer newNode = new NodeBuyer(tail, item, null);
            tail.next = newNode; 
            tail = newNode; 
        }
        size++; 
    }

    public Buyer removeFirst() {
        if (isEmpty()) {
            System.out.println("Antrian kosong!");
            return null;
        }
        Buyer removedData = head.data;
        if (head == tail) {
            head = null;
            tail = null; 
        } else {
            head = head.next; 
            head.prev = null; 
        }
        size--;
        return removedData;
    }

    public void printQueue() {
        if (isEmpty()) {
            System.out.println("Antrian kosong.");
            return;
        }
        System.out.println("========================================");
        System.out.println("Daftar Antrian Pembeli"); 
        System.out.println("========================================");
        System.out.printf("%-15s %-15s %-15s\n", "No Antrian", "Nama", "No HP");
        NodeBuyer current = head;
        while (current != null) {
            System.out.printf("%-15d %-15s %-15s\n", current.data.queueNumber, current.data.name, current.data.mobileNumber);
            current = current.next;
        }
    }
}